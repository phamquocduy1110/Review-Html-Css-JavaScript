package com.phamquocduy.ReviewHtml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewHtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewHtmlApplication.class, args);
	}

}
