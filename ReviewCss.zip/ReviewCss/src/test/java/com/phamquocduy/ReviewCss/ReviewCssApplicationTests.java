package com.phamquocduy.ReviewCss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewCssApplicationTests {

	@Test
	void contextLoads() {
	}

}
