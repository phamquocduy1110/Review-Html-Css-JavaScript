package com.phamquocduy.ReviewJavaScript;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewJavaScriptApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewJavaScriptApplication.class, args);
	}

}
